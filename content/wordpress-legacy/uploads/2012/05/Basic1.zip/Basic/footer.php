<div style="clear: both;"></div>
</div>
<div id="footer"> <?php esc_html_e('Powered by ','Basic'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','Basic'); ?> <a href="http://www.elegantthemes.com">Elegant Themes</a> </div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>
